package com.erdin.latihanandroidweek1

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class OneActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_one)
    }
}