package com.erdin.latihanandroidweek1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class TwoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_two)
    }
}